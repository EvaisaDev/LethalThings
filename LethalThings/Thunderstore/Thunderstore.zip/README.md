# LethalThings
**A content mod for Lethal Company, currently only adds 1 new scrap item.**
  
*Currently includes:*
- Plushie named Arson  
![Arson](https://cdn.discordapp.com/attachments/946794297418739742/1174367498041311333/image.png)

**Credits:**
- Bobilka for models

# Latest Changes  
   
- Update store image