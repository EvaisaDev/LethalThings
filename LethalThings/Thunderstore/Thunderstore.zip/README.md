# LethalThings
**A content mod for Lethal Company, currently only adds 6 scrap items, 4 store items, and 1 game mechanic.**  
*List of included content below*  

## Scrap items
- Plushy named Arson  
	- May set your house on fire if you displease her.  
![Arson](https://i.imgur.com/OnCGKcl.png)
  
- Plushy named arson (Dirty)  
	- Ew stinky  
![Arson](https://i.imgur.com/Buk3lQ2.png)
  
- Toimari plushy  
	- Noita reference  
![Toimari](https://i.imgur.com/STXtpHc.png)
  
- Hämis plushy  
	- Very soft.  
	- May nibble you a little.  
![Hämis](https://i.imgur.com/rM41HbK.png)
  
- Cookie Fumo  
	- Says strange things when you squeeze her.  
![Cookie](https://i.imgur.com/aMiji2H.png)
  
- Maxwell
	- Purrs loudly.  
	- Meows.  
	- Plays a silly little song.  
	- Does a silly little dance.  
![Maxwell](https://i.imgur.com/nccQTQy.png)
  
## Store items
- Toy Hammer
	- Good for bonking unruly employees.  
	- We are not responsible for any fatalities related to this item.  
	- Clowns are known to love this one.  
![Hammer](https://i.imgur.com/UDtb5GC.png)
  
- Rocket Launcher  
	- For if you want to go on the offense.  
	- Only has 4 shots.  
	- Highly fatal to team members.  
![RocketLauncher](https://i.imgur.com/lzDTH3E.png)
  
- Utility Belt  
	- Additional storage for scrap.  
	- +10 charisma.  
![Belt](https://i.imgur.com/Jlt0Hmi.png)
  
- Remote Radar
	- Access the ship radar system remotely.  
	- Very limited battery life.  
	- May piss off anyone actively watching the radar terminal.  
![RemoteRadar](https://i.imgur.com/7cdQeNm.png)

## Miscelaneous
- Improved Item Charger.  
	- Stuffing conductive items in the charger will now electrocute you.  

## Credits:
- Bobilka   
	- Models  
	- Ideas  
	- Textures  
	- Testing  
- Antlers  
	- Models  
	- Cookie  

# Latest Changes  
   
- Added 5 scrap
- Added 4 store items
- Added 1 game mechanic
