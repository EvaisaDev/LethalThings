# LethalThings
**A content mod for Lethal Company**  
*List of included content below*  

## Scrap items
- Plushy named Arson  
	- May set your house on fire if you displease her.  
![Arson](https://i.imgur.com/OnCGKcl.png)
  
- Plushy named arson (Dirty)  
	- Ew stinky  
![Arson](https://i.imgur.com/Buk3lQ2.png)
  
- Toimari plushy  
	- Noita reference  
![Toimari](https://i.imgur.com/STXtpHc.png)
  
- Hämis plushy  
	- Very soft.  
	- May nibble you a little.  
![Hämis](https://i.imgur.com/rM41HbK.png)
  
- Cookie Fumo  
	- Says strange things when you squeeze her.  
![Cookie](https://i.imgur.com/aMiji2H.png)
  
- Maxwell
	- Purrs loudly.  
	- Meows.  
	- Plays a silly little song.  
	- Does a silly little dance.  
![Maxwell](https://i.imgur.com/nccQTQy.png)
  
## Store items
- Toy Hammer
	- Good for bonking unruly employees.  
	- We are not responsible for any fatalities related to this item.  
	- Clowns are known to love this one.  
![Hammer](https://i.imgur.com/UDtb5GC.png)
  
- Rocket Launcher  
	- For if you want to go on the offense.  
	- Only has 4 shots.  
	- Highly fatal to team members.  
![RocketLauncher](https://i.imgur.com/lzDTH3E.png)
  
- Utility Belt  
	- Additional storage for scrap.  
	- +10 charisma.  
![Belt](https://i.imgur.com/Jlt0Hmi.png)  
  
- Remote Radar
	- Access the ship radar system remotely.  
	- Very limited battery life.   
	- May piss off anyone actively watching the radar terminal.    
![RemoteRadar](https://i.imgur.com/7cdQeNm.png)  
  
- Hacking Tool  
	- Unlock gates, disable turrets and mines, from up close.  
	- Requires basic math skills.  
![HackingTool](https://cdn.discordapp.com/attachments/511206402493251586/1180890040990171186/g-3dUIk1R.png)  

## Decor  
- Small/Large Rug  
	- Improve your living space!  
![Rugs](https://i.imgur.com/JXXXeoW.png)
   
- Fatalities Sign
	- A sign which reflects the efficacity of your crew.  
	- Automatically updates.  
![FatalitiesSign](https://cdn.discordapp.com/attachments/511206402493251586/1180888999951355985/sSk78gIYS.png)  

## Enemies
- Boomba  
	- A cute little robot.  
![Boomba](https://i.imgur.com/HbKHfJU.png)
	
## Map Hazards
- Teleporter Trap  
	- Teleports you to a random place in the facility when you step on it.  
![TeleporterTrap](https://i.imgur.com/BWPRBwW.png)

## Miscelaneous
- Improved Item Charger.  
	- Stuffing conductive items in the charger will now electrocute you.  

## Credits:
- [Bobilka](https://bsky.app/profile/bobilka.bsky.social)   
	- Models  
	- Ideas  
	- Textures  
	- Testing  
- Antlers  
	- Models  
	- Cookie  
- LocalHyena  
	- Models  
	- Textures  

# Latest Changes  
- Updated maxwell (funny)  
- Added audio volume config file.  
- Fixed Boomba map dot  
	
